<header class="kepala-situs">
    <h1>Perpustakaan Digital</h1>
    <p>Sistem Informasi Perpustakaan</p>
</header>

<nav class="menu-utama">
    <div class="menu-dalam">

        <div class="menu-kiri">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('home')]); ?>">Beranda</a>

            <?php if(auth()->guard()->check()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat daftar buku')): ?>
                    <a href="<?php echo e(route('buku.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('buku.*')]); ?>">Daftar Buku</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akses dashboard admin')): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('admin.dashboard')]); ?>">Dashboard Admin</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akses dashboard petugas')): ?>
                    <a href="<?php echo e(route('petugas.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('petugas.dashboard')]); ?>">Dashboard Petugas</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('admin.users.*')]); ?>">Pengguna</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola peminjaman')): ?>
                    <a href="<?php echo e(route('kelola.peminjaman.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('kelola.peminjaman.*')]); ?>">Peminjaman</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola pengembalian')): ?>
                    <a href="<?php echo e(route('kelola.pengembalian.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('kelola.pengembalian.*')]); ?>">Pengembalian</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat laporan perpustakaan')): ?>
                    <a href="<?php echo e(route('laporan.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('laporan.*')]); ?>">Laporan</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('melihat status peminjaman sendiri')): ?>
                    <a href="<?php echo e(route('peminjaman-saya.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('peminjaman-saya.*')]); ?>">Peminjaman Saya</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="menu-kanan">
            <?php if(auth()->guard()->check()): ?>
                <?php ($peran = auth()->user()->getRoleNames()->first() ?? 'pengguna'); ?>
                <span class="info-pengguna">
                    <?php echo e(auth()->user()->name); ?>

                    <span class="lencana lencana-<?php echo e($peran); ?>"><?php echo e(ucfirst($peran)); ?></span>
                </span>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat profil sendiri')): ?>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('profile.*')]); ?>">Profil</a>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('logout')); ?>" class="form-keluar"
                    data-konfirmasi="Yakin ingin keluar dari akun?">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="tautan-keluar">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('login')]); ?>">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs('register')]); ?>">Daftar</a>
            <?php endif; ?>
        </div>

    </div>
</nav><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/layouts/partials/atas.blade.php ENDPATH**/ ?>