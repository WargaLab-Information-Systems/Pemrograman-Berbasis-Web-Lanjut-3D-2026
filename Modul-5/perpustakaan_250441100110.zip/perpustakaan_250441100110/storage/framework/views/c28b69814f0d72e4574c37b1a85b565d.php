<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('judul', 'Perpustakaan'); ?> | Perpustakaan Digital</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/perpustakaan.css']); ?>
</head>

<body>
    <div class="halaman">
        <?php echo $__env->make('layouts.partials.atas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main>
            <?php echo $__env->yieldContent('konten'); ?>
        </main>

        <?php echo $__env->make('layouts.partials.bawah', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/layouts/perpustakaan.blade.php ENDPATH**/ ?>