<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'tombol'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/components/primary-button.blade.php ENDPATH**/ ?>