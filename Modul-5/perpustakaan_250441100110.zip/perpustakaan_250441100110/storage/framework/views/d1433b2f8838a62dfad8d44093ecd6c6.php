<?php $__env->startSection('judul', 'Dashboard Admin'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Dashboard Admin</h2>
    <p class="sub-halaman">Ringkasan data perpustakaan dan akses pengelolaan.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <div class="kartu">
        <h3>Selamat datang, <?php echo e(auth()->user()->name); ?></h3>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <p>Anda masuk sebagai <strong>Admin</strong> dan dapat mengelola seluruh kebutuhan administrasi perpustakaan.</p>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
            <div class="pesan pesan-sukses">Anda memiliki hak akses untuk <strong>kelola data pengguna</strong>.</div>
        <?php endif; ?>
    </div>

    <div class="grid-ringkas">
        <?php $__currentLoopData = [
            'Total buku' => $totalBuku,
            'Admin' => $totalAdmin,
            'Petugas' => $totalPetugas,
            'Siswa' => $totalSiswa,
            'Menunggu persetujuan' => $diajukan,
            'Sedang dipinjam' => $dipinjam,
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="kartu-angka">
                <span class="label"><?php echo e($label); ?></span>
                <span class="nilai"><?php echo e($nilai); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="kartu">
        <h3>Menu Cepat</h3>
        <div class="aksi-baris">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
                <a class="tombol" href="<?php echo e(route('admin.users.index')); ?>">Kelola Pengguna</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data buku')): ?>
                <a class="tombol" href="<?php echo e(route('buku.index')); ?>">Kelola Buku</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola peminjaman')): ?>
                <a class="tombol" href="<?php echo e(route('kelola.peminjaman.index')); ?>">Peminjaman</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola pengembalian')): ?>
                <a class="tombol" href="<?php echo e(route('kelola.pengembalian.index')); ?>">Pengembalian</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat laporan perpustakaan')): ?>
                <a class="tombol" href="<?php echo e(route('laporan.index')); ?>">Laporan</a>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>