<?php $__env->startSection('judul', 'Kelola Pengembalian'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Kelola Pengembalian</h2>
    <p class="sub-halaman">Catat pengembalian buku yang sedang dipinjam.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <div class="kartu">
        <h3>Sedang Dipinjam</h3>
        <div class="bungkus-tabel">
            <table class="tabel-data">
                <thead>
                    <tr><th>ID</th><th>Peminjam</th><th>Buku</th><th>Tanggal pinjam</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dipinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->anggota->nama); ?></td>
                            <td><?php echo e($p->buku->judul); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mencatat pengembalian buku')): ?>
                                    <form method="POST" action="<?php echo e(route('kelola.pengembalian.kembalikan', $p)); ?>" class="sebaris"
                                            data-konfirmasi="Catat pengembalian buku <?php echo e($p->buku->judul); ?> dari <?php echo e($p->anggota->nama); ?>?">
                                        <button class="tombol tombol-kecil">Catat Pengembalian</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="tabel-kosong">Tidak ada buku yang sedang dipinjam.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="kartu">
        <h3>Pengembalian Terbaru</h3>
        <div class="bungkus-tabel">
            <table class="tabel-data">
                <thead>
                    <tr><th>Peminjam</th><th>Buku</th><th>Tanggal kembali</th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->anggota->nama); ?></td>
                            <td><?php echo e($p->buku->judul); ?></td>
                            <td><?php echo e($p->tanggal_kembali); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="tabel-kosong">Belum ada pengembalian.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/peminjaman/pengembalian.blade.php ENDPATH**/ ?>