<?php if(session('status')): ?>
    <div class="pesan pesan-sukses"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="pesan pesan-gagal">
        <ul class="daftar-error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($pesan); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/components/flash.blade.php ENDPATH**/ ?>