<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Perpustakaan Digital</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/perpustakaan.css', 'resources/js/app.js']); ?>
</head>

<body>
    <div class="halaman">
        <?php echo $__env->make('layouts.partials.atas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main>
            <div class="kotak-masuk">
                <?php echo e($slot); ?>

            </div>
        </main>

        <?php echo $__env->make('layouts.partials.bawah', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/layouts/guest.blade.php ENDPATH**/ ?>