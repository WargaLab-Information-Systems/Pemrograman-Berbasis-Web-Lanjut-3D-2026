<?php $__env->startSection('judul', 'Laporan Perpustakaan'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Laporan Perpustakaan</h2>
    <p class="sub-halaman">Ringkasan koleksi, anggota, dan peminjaman.</p>

    <div class="grid-ringkas">
        <?php $__currentLoopData = $ringkasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="kartu-angka">
                <span class="label"><?php echo e($label); ?></span>
                <span class="nilai"><?php echo e($nilai); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="kartu">
        <h3>Buku Paling Sering Dipinjam</h3>
        <div class="bungkus-tabel">
            <table class="tabel-data">
                <thead><tr><th>Peringkat</th><th>Judul</th><th>Jumlah dipinjam</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $populer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($b->judul); ?></td>
                            <td><?php echo e($b->peminjamans_count); ?> kali</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="kartu">
        <h3>10 Peminjaman Terbaru</h3>
        <div class="bungkus-tabel">
            <table class="tabel-data">
                <thead><tr><th>Peminjam</th><th>Buku</th><th>Tanggal</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->anggota->nama); ?></td>
                            <td><?php echo e($p->buku->judul); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td><span class="lencana lencana-<?php echo e($p->status); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/laporan/index.blade.php ENDPATH**/ ?>