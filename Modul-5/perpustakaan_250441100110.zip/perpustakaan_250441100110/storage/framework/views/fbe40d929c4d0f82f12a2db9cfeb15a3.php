

<?php $__env->startSection('judul', 'Beranda'); ?>

<?php $__env->startSection('konten'); ?>
<?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <section class="hero">
        <h2>Selamat Datang di Perpustakaan Digital</h2>
        <p>Lihat koleksi buku, ajukan peminjaman, dan pantau riwayat peminjaman Anda dalam satu tempat.</p>

        <div class="aksi-baris pusat">
            <?php if(auth()->guard()->check()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat daftar buku')): ?>
                    <a class="tombol tombol-besar" href="<?php echo e(route('buku.index')); ?>">Lihat Daftar Buku</a>
                <?php endif; ?>
                <a class="tombol tombol-garis tombol-besar" href="<?php echo e(route('dashboard')); ?>">Ke Dashboard</a>
            <?php else: ?>
                <a class="tombol tombol-besar" href="<?php echo e(route('login')); ?>">Masuk</a>
                <a class="tombol tombol-garis tombol-besar" href="<?php echo e(route('register')); ?>">Daftar</a>
            <?php endif; ?>
        </div>
    </section>

    <div class="grid-ringkas">
        <div class="kartu-angka">
            <span class="label">Koleksi</span>
            <span class="nilai" style="font-size:1.2rem">Katalog buku lengkap</span>
        </div>
        <div class="kartu-angka">
            <span class="label">Peminjaman</span>
            <span class="nilai" style="font-size:1.2rem">Ajukan secara online</span>
        </div>
        <div class="kartu-angka">
            <span class="label">Riwayat</span>
            <span class="nilai" style="font-size:1.2rem">Pantau milik sendiri</span>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/home.blade.php ENDPATH**/ ?>