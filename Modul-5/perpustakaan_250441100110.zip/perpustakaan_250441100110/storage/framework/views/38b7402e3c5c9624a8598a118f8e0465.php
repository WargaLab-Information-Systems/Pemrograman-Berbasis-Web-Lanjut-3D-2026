<?php $__env->startSection('judul', 'Kelola Pengguna'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Kelola Pengguna dan Role</h2>
    <p class="sub-halaman">Tambah akun, tetapkan role, dan hapus akun pengguna.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
        <div class="kartu">
            <h3>Tambah Pengguna</h3>
            <form method="POST" action="<?php echo e(route('admin.users.store')); ?>"
                    data-konfirmasi="Tambahkan pengguna baru ini?">
                <?php echo csrf_field(); ?>
                <div class="grid-form">
                    <div class="baris-form">
                        <label for="name">Nama</label>
                        <input id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                    </div>
                    <div class="baris-form">
                        <label for="email">Email</label>
                        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                    </div>
                    <div class="baris-form">
                        <label for="password">Password</label>
                        <input id="password" type="password" name="password" placeholder="Minimal 8 karakter" required>
                    </div>
                    <div class="baris-form">
                        <label for="role">Role</label>
                        <select id="role" name="role">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($r); ?>" <?php if(old('role') === $r): echo 'selected'; endif; ?>><?php echo e(ucfirst($r)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <button class="tombol">Tambah Pengguna</button>
            </form>
        </div>
    <?php endif; ?>

    <div class="bungkus-tabel">
        <table class="tabel-data">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola role pengguna')): ?>
                                <form method="POST" action="<?php echo e(route('admin.users.role', $u)); ?>" class="sebaris"
                                        data-konfirmasi="Simpan perubahan role untuk <?php echo e($u->name); ?>?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <select name="role" class="kontrol kontrol-kecil">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r); ?>" <?php if($u->hasRole($r)): echo 'selected'; endif; ?>><?php echo e(ucfirst($r)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="tombol tombol-kecil">Simpan role</button>
                                </form>
                            <?php else: ?>
                                <?php $__currentLoopData = $u->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="lencana lencana-<?php echo e($nama); ?>"><?php echo e(ucfirst($nama)); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
                                <?php if($u->id !== auth()->id()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.destroy', $u)); ?>" class="sebaris"
                                            data-konfirmasi="Hapus pengguna <?php echo e($u->name); ?>? Tindakan ini tidak dapat dibatalkan.">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="tombol tombol-kecil tombol-merah">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/admin/users/index.blade.php ENDPATH**/ ?>