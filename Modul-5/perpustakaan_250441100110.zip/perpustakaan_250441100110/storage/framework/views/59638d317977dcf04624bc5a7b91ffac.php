<?php $__env->startSection('judul', 'Kelola Peminjaman'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Kelola Peminjaman</h2>
    <p class="sub-halaman">Setujui atau tolak pengajuan peminjaman buku.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <div class="bungkus-tabel">
        <table class="tabel-data">
            <thead>
                <tr>
                    <th>ID</th><th>Peminjam</th><th>Buku</th><th>Tanggal</th><th>Status</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($p->id); ?></td>
                        <td><?php echo e($p->anggota->nama); ?></td>
                        <td><?php echo e($p->buku->judul); ?></td>
                        <td><?php echo e($p->tanggal_pinjam); ?></td>
                        <td><span class="lencana lencana-<?php echo e($p->status); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
                        <td>
                            <div class="aksi-baris">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('memproses persetujuan peminjaman')): ?>
                                    <?php if($p->status === 'diajukan'): ?>
                                        <form method="POST" action="<?php echo e(route('kelola.peminjaman.setujui', $p)); ?>" class="sebaris"
                                                data-konfirmasi="Setujui peminjaman buku <?php echo e($p->buku->judul); ?> oleh <?php echo e($p->anggota->nama); ?>?">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button class="tombol tombol-kecil tombol-hijau">Setujui</button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('kelola.peminjaman.tolak', $p)); ?>" class="sebaris"
                                                data-konfirmasi="Tolak pengajuan buku <?php echo e($p->buku->judul); ?> oleh <?php echo e($p->anggota->nama); ?>?">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button class="tombol tombol-kecil tombol-merah">Tolak</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <a class="tombol tombol-kecil tombol-biru" href="<?php echo e(route('peminjaman-saya.show', $p)); ?>">Detail</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="tabel-kosong">Belum ada data peminjaman.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/peminjaman/kelola.blade.php ENDPATH**/ ?>