<?php $__env->startSection('judul', 'Peminjaman Saya'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Peminjaman Saya</h2>
    <p class="sub-halaman">Ajukan peminjaman dan pantau status serta riwayat peminjaman milik Anda.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mengajukan peminjaman buku')): ?>
        <div class="kartu">
            <h3>Ajukan Peminjaman</h3>
            <form method="POST" action="<?php echo e(route('peminjaman-saya.store')); ?>" class="aksi-baris"
                    data-konfirmasi="Ajukan peminjaman untuk buku yang dipilih?">
                <?php echo csrf_field(); ?>
                <select name="buku_id" class="kontrol kontrol-lebar" required>
                    <option value="">-- Pilih buku --</option>
                    <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>"><?php echo e($b->judul); ?> (<?php echo e($b->penulis); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="tombol">Ajukan Peminjaman</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('melihat status peminjaman sendiri')): ?>
        <div class="kartu">
            <h3>Status Peminjaman</h3>
            <div class="bungkus-tabel">
                <table class="tabel-data">
                    <thead>
                        <tr><th>Buku</th><th>Tanggal</th><th>Status</th><th>Detail</th></tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $aktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($p->buku->judul); ?></td>
                                <td><?php echo e($p->tanggal_pinjam); ?></td>
                                <td><span class="lencana lencana-<?php echo e($p->status); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
                                <td><a class="tombol tombol-kecil tombol-biru" href="<?php echo e(route('peminjaman-saya.show', $p)); ?>">Lihat</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="tabel-kosong">Tidak ada peminjaman aktif.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('melihat riwayat peminjaman sendiri')): ?>
        <div class="kartu">
            <h3>Riwayat Peminjaman</h3>
            <div class="bungkus-tabel">
                <table class="tabel-data">
                    <thead>
                        <tr><th>Buku</th><th>Dipinjam</th><th>Dikembalikan</th><th>Status</th><th>Detail</th></tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($p->buku->judul); ?></td>
                                <td><?php echo e($p->tanggal_pinjam); ?></td>
                                <td><?php echo e($p->tanggal_kembali ?? '-'); ?></td>
                                <td><span class="lencana lencana-<?php echo e($p->status); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
                                <td><a class="tombol tombol-kecil tombol-biru" href="<?php echo e(route('peminjaman-saya.show', $p)); ?>">Lihat</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="tabel-kosong">Belum ada riwayat.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/peminjaman/saya.blade.php ENDPATH**/ ?>