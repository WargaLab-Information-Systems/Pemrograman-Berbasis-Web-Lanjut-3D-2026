<?php $__env->startSection('title', 'Manajemen Data Buku - Modul IV'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-title">
        <h2>Manajemen Buku</h2>
        <p>
            Koleksi buku perpustakaan 
        </p>
    </div>

    
    <div id="alert-box" class="alert" style="display: none;"></div>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-buku')): ?>
    <div class="crud-card form-card">
        <div class="crud-card-header">
            <div>
                <span id="form-badge" class="badge-pill badge-primary">Form Tambah</span>
                <h3 id="form-title" style="margin-top: 6px;">Tambah Buku Baru</h3>
            </div>
            <button type="button" id="btn-cancel-top" class="btn btn-sm btn-secondary" style="display: none;" onclick="batalEdit()">
                ✕ Batal Ubah
            </button>
        </div>

        <form id="form-buku" onsubmit="handleFormSubmit(event)">
            
            <input type="hidden" id="buku-id" value="">

            <div class="form-grid">
                <div class="form-group">
                    <label for="kategori_id">Kategori Buku <span class="required">*</span></label>
                    <select id="kategori_id" name="kategori_id" class="form-control" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php if(isset($kategoris)): ?>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kat->id); ?>"><?php echo e($kat->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="judul">Judul Buku <span class="required">*</span></label>
                    <input type="text" id="judul" name="judul" class="form-control" placeholder="Masukkan judul buku" required minlength="3" maxlength="150">
                </div>

                <div class="form-group">
                    <label for="penulis">Penulis <span class="required">*</span></label>
                    <input type="text" id="penulis" name="penulis" class="form-control" placeholder="Masukkan nama penulis" required minlength="3" maxlength="100">
                </div>

                <div class="form-group">
                    <label for="tahun_terbit">Tahun Terbit <span class="required">*</span></label>
                    <input type="number" id="tahun_terbit" name="tahun_terbit" class="form-control" placeholder="Contoh: 2024" required min="1900" max="<?php echo e(date('Y')); ?>">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" id="btn-submit" class="btn btn-primary">
                    <span id="btn-submit-text">Simpan Buku</span>
                </button>
                <button type="button" id="btn-cancel" class="btn btn-secondary" style="display: none;" onclick="batalEdit()">
                    Batal
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    
    <div class="crud-card table-card">
        <div class="crud-card-header">
            <div>
                <h3>Daftar Buku</h3>
                <small class="text-muted">Data diambil dari endpoint <code>GET /api/buku</code> melalui API Resource</small>
            </div>
            <button type="button" class="btn btn-sm btn-outline" onclick="tampilkanBuku()">
                🔄 Muat Ulang
            </button>
        </div>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">No</th>
                        <th>Judul Buku</th>
                        <th>Kategori</th>
                        <th>Penulis</th>
                        <th>Tahun Terbit</th>
                        <th style="width: 170px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tabel-buku-body">
                    
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Memuat data buku...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="crud-card">
        <div class="crud-card-header">
            <h3>Daftar Judul Buku (Blade)</h3>
        </div>
        <ul>
            <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e(data_get($buku, 'judul')); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.daftarBukuCache = <?php echo json_encode($bukus, 15, 512) ?>;
        window.bolehKelolaBuku = <?php echo json_encode(auth()->user()->can('kelola-buku'), 15, 512) ?>;
        window.bolehPinjamBuku = <?php echo json_encode(auth()->user()->can('mengajukan peminjaman buku'), 15, 512) ?>;
        window.apiBukuUrl = <?php echo json_encode(url('/api/buku'), 15, 512) ?>;
        window.apiPeminjamanUrl = <?php echo json_encode(url('/api/peminjaman'), 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('js/buku.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100112\resources\views/buku/index.blade.php ENDPATH**/ ?>