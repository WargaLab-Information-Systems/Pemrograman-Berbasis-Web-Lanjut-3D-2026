<?php $__env->startSection('judul', 'Detail Peminjaman'); ?>

<?php $__env->startSection('konten'); ?>

    <div class="detail-buku">
        <div class="detail-card">
            <p class="label-detail">DETAIL PEMINJAMAN #<?php echo e($peminjaman->id); ?></p>
            <h2><?php echo e($peminjaman->buku->judul); ?></h2>

            <div class="info-buku">
                <p><strong>Peminjam</strong><span><?php echo e($peminjaman->anggota->nama); ?></span></p>
                <p><strong>Kategori</strong><span><?php echo e($peminjaman->buku->kategori->nama); ?></span></p>
                <p><strong>Tanggal pinjam</strong><span><?php echo e($peminjaman->tanggal_pinjam); ?></span></p>
                <p><strong>Tanggal kembali</strong><span><?php echo e($peminjaman->tanggal_kembali ?? '-'); ?></span></p>
                <p><strong>Status</strong><span class="lencana lencana-<?php echo e($peminjaman->status); ?>"><?php echo e(ucfirst($peminjaman->status)); ?></span></p>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola peminjaman')): ?>
                <a class="tombol-kembali" href="<?php echo e(route('kelola.peminjaman.index')); ?>">Kembali</a>
            <?php else: ?>
                <a class="tombol-kembali" href="<?php echo e(route('peminjaman-saya.index')); ?>">Kembali</a>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/peminjaman/detail.blade.php ENDPATH**/ ?>