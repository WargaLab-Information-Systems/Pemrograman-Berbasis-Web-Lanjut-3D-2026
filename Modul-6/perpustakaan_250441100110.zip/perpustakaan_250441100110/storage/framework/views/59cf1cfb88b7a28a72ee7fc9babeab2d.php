

<?php $__env->startSection('judul', 'Daftar Buku'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman">Daftar Buku</h2>
    <p class="sub-halaman">Koleksi buku perpustakaan.</p>

    <?php if (isset($component)) { $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $attributes = $__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__attributesOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2)): ?>
<?php $component = $__componentOriginal5168fdb0c14fd91c6598264bc4be63f2; ?>
<?php unset($__componentOriginal5168fdb0c14fd91c6598264bc4be63f2); ?>
<?php endif; ?>

    <div class="aksi-baris" style="margin-bottom:16px">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-buku')): ?>
            <a href="<?php echo e(route('buku.create')); ?>" class="tombol">Tambah Buku</a>
        <?php endif; ?>
        <a href="<?php echo e(route('buku.fetch')); ?>" class="tombol tombol-garis">Tampilan Fetch</a>
    </div>

    <div class="bungkus-tabel">
        <table class="tabel-buku">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kategori</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Tahun Terbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($bukus->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($b->kategori->nama ?? '-'); ?></td>
                        <td><?php echo e($b->judul); ?></td>
                        <td><?php echo e($b->penulis); ?></td>
                        <td><?php echo e($b->tahun_terbit); ?></td>
                        <td>
                            <div class="aksi-baris">
                                <a class="tombol tombol-kecil tombol-biru" href="<?php echo e(route('buku.detail', $b->id)); ?>">Detail</a>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-buku')): ?>
                                    <a class="tombol tombol-kecil" href="<?php echo e(route('buku.edit', $b)); ?>">Ubah</a>

                                    <form method="POST" action="<?php echo e(route('buku.destroy', $b)); ?>" class="sebaris"
                                          data-konfirmasi="Hapus buku <?php echo e($b->judul); ?>?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="tombol tombol-kecil tombol-merah">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="tabel-kosong">Belum ada buku.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="paginasi">
        <?php if($bukus->onFirstPage()): ?>
            <span class="tombol tombol-abu" style="opacity:.5">Sebelumnya</span>
        <?php else: ?>
            <a class="tombol tombol-abu" href="<?php echo e($bukus->previousPageUrl()); ?>">Sebelumnya</a>
        <?php endif; ?>

        <span>Halaman <?php echo e($bukus->currentPage()); ?> dari <?php echo e($bukus->lastPage()); ?></span>

        <?php if($bukus->hasMorePages()): ?>
            <a class="tombol tombol-abu" href="<?php echo e($bukus->nextPageUrl()); ?>">Berikutnya</a>
        <?php else: ?>
            <span class="tombol tombol-abu" style="opacity:.5">Berikutnya</span>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/buku/index.blade.php ENDPATH**/ ?>