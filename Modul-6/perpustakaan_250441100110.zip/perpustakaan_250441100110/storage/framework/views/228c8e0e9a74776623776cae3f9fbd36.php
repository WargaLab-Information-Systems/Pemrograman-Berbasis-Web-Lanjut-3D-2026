

<?php $__env->startSection('judul', '403 - Akses Ditolak'); ?>

<?php $__env->startSection('konten'); ?>
    <div style="text-align:center; padding: 60px 20px;">
        <h1 style="font-size: 32px; margin-bottom: 12px;">403 - AKSES DITOLAK</h1>
        <p style="font-size: 16px; opacity: .85;">
            Akun kamu tidak memiliki hak akses untuk membuka halaman atau data ini.
        </p>
        <a href="<?php echo e(route('buku.index')); ?>" class="tombol tombol-abu" style="margin-top:20px; display:inline-block;">
            Kembali ke Daftar Buku
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/errors/403.blade.php ENDPATH**/ ?>