

<?php $__env->startSection('judul', 'Detail Buku'); ?>

<?php $__env->startSection('konten'); ?>

    <div class="detail-buku">

        <?php if($buku): ?>

            <div class="detail-card">

                <p class="label-detail">DETAIL BUKU</p>

                <h2><?php echo e($buku['judul']); ?></h2>

                <div class="info-buku">
                    <p>
                        <strong>Penulis</strong>
                        <span><?php echo e($buku['penulis']); ?></span>
                    </p>

                    <p>
                        <strong>Tahun Terbit</strong>
                        <span><?php echo e($buku['tahun']); ?></span>
                    </p>

                    <p>
                        <strong>Kategori</strong>
                        <span><?php echo e($buku['kategori']); ?></span>
                    </p>
                </div>

                <a class="tombol-kembali" href="<?php echo e(route('buku.index')); ?>">
                    Kembali ke Daftar Buku
                </a>

            </div>

        <?php else: ?>

            <div class="detail-card">
                <h2>Buku Tidak Ditemukan</h2>

                <p>Data buku yang Anda cari tidak tersedia.</p>

                <a class="tombol-kembali" href="<?php echo e(route('buku.index')); ?>">
                    Kembali ke Daftar Buku
                </a>
            </div>

        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/buku/detail.blade.php ENDPATH**/ ?>