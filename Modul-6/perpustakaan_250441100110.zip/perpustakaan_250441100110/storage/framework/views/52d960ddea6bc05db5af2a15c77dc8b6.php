

<?php $__env->startSection('judul', $buku->exists ? 'Ubah Buku' : 'Tambah Buku'); ?>

<?php $__env->startSection('konten'); ?>

    <h2 class="judul-halaman"><?php echo e($buku->exists ? 'Ubah Buku' : 'Tambah Buku'); ?></h2>
    <p class="sub-halaman">Isi data buku lalu simpan.</p>

    <form method="POST"
          action="<?php echo e($buku->exists ? route('buku.update', $buku) : route('buku.store')); ?>"
          class="form-buku"
          data-konfirmasi="<?php echo e($buku->exists ? 'Simpan perubahan pada buku ini?' : 'Tambahkan buku baru ini?'); ?>">
        <?php echo csrf_field(); ?>
        <?php if($buku->exists): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="grid-form">
            <div class="baris-form">
                <label for="kategori_id">ID Kategori</label>
                <input type="number" id="kategori_id" name="kategori_id" min="1"
                       value="<?php echo e(old('kategori_id', $buku->kategori_id)); ?>" placeholder="Contoh: 1">
                <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error-field"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="baris-form">
                <label for="judul">Judul</label>
                <input type="text" id="judul" name="judul"
                       value="<?php echo e(old('judul', $buku->judul)); ?>" placeholder="Judul buku">
                <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error-field"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="baris-form">
                <label for="penulis">Penulis</label>
                <input type="text" id="penulis" name="penulis"
                       value="<?php echo e(old('penulis', $buku->penulis)); ?>" placeholder="Nama penulis">
                <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error-field"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="baris-form">
                <label for="tahun_terbit">Tahun Terbit</label>
                <input type="number" id="tahun_terbit" name="tahun_terbit"
                       value="<?php echo e(old('tahun_terbit', $buku->tahun_terbit)); ?>" placeholder="Contoh: 2015">
                <?php $__errorArgs = ['tahun_terbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="error-field"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="aksi-baris">
            <button type="submit" class="tombol"><?php echo e($buku->exists ? 'Perbarui' : 'Simpan'); ?></button>
            <a href="<?php echo e(route('buku.index')); ?>" class="tombol tombol-abu">Batal</a>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.perpustakaan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100110\resources\views/buku/form.blade.php ENDPATH**/ ?>